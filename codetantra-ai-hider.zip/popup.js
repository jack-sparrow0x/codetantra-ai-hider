const toggle = document.getElementById("toggle");
const status = document.getElementById("status");

async function loadState() {
  const { hideAI = false } = await chrome.storage.local.get("hideAI");

  toggle.checked = hideAI;
  updateStatus(hideAI);
}

toggle.addEventListener("change", async () => {
  const enabled = toggle.checked;

  await chrome.storage.local.set({
    hideAI: enabled
  });

  updateStatus(enabled);
});

function updateStatus(enabled) {
  status.textContent = enabled ? "ON" : "OFF";
  status.style.color = enabled ? "#3b82f6" : "#888891";
}

loadState();