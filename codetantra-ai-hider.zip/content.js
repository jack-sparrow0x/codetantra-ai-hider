let hideSensAI = false;

const LAUNCHER_SELECTOR =
  'button[title^="SensAI - Your AI Assistant for learning"]';

function hideLauncher() {
  document.querySelectorAll(LAUNCHER_SELECTOR).forEach((element) => {
    if (hideSensAI) {
      element.style.setProperty(
        "display",
        "none",
        "important"
      );
    } else {
      element.style.removeProperty("display");
    }
  });
}

function findOnboardingPopup() {
  return [...document.querySelectorAll("div")].find(
    (element) =>
      element.textContent.includes("Get Started with AI") &&
      element.textContent.includes("Start using AI features")
  );
}

function hideOnboardingPopup() {
  const popup = findOnboardingPopup();

  if (!popup) return;

  if (hideSensAI) {
    popup.style.setProperty(
      "display",
      "none",
      "important"
    );
  } else {
    popup.style.removeProperty("display");
  }
}

function applyState() {
  hideLauncher();
  hideOnboardingPopup();
}

// Get current state when this frame loads
chrome.storage.local.get("hideAI", (result) => {
  hideSensAI = result.hideAI === true;
  applyState();
});

// THIS is the important part.
// It works across the different frames automatically.
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;

  if (changes.hideAI) {
    hideSensAI = changes.hideAI.newValue === true;
    applyState();
  }
});

// CodeTantra dynamically creates/removes UI.
const observer = new MutationObserver(() => {
  if (hideSensAI) {
    applyState();
  }
});

observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});
