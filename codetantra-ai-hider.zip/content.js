let hideSensAI = false;

const LAUNCHER_SELECTOR = 'button[title^="SensAI - Your AI Assistant for learning"]';
const TOOLS_STRIP_SELECTOR = 'div.ai-tools-strip[role="toolbar"]';
const DIALOG_SELECTOR = 'div.fixed[role="dialog"]';

function hideElementBySelector(selector) {
  document.querySelectorAll(selector).forEach((element) => {
    if (hideSensAI) {
      element.style.setProperty("display", "none", "important");
    } else {
      element.style.removeProperty("display");
    }
  });
}

function findOnboardingPopup() {
  return [...document.querySelectorAll("div")].find(
    (element) =>
      element.textContent.includes("Get Started with AI") &&
      element.textContent.includes("Start using AI features")
  );
}

function hideOnboardingPopup() {
  const popup = findOnboardingPopup();
  if (!popup) return;

  if (hideSensAI) {
    popup.style.setProperty("display", "none", "important");
  } else {
    popup.style.removeProperty("display");
  }
}

function applyState() {
  hideElementBySelector(LAUNCHER_SELECTOR);
  hideElementBySelector(TOOLS_STRIP_SELECTOR);
  hideElementBySelector(DIALOG_SELECTOR);
  hideOnboardingPopup();
}

// Get current state when this frame loads
chrome.storage.local.get("hideAI", (result) => {
  hideSensAI = result.hideAI === true;
  applyState();
});

// Listen for state changes across frames automatically
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;

  if (changes.hideAI) {
    hideSensAI = changes.hideAI.newValue === true;
    applyState();
  }
});

// CodeTantra dynamically creates/removes UI.
const observer = new MutationObserver(() => {
  if (hideSensAI) {
    applyState();
  }
});

observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});