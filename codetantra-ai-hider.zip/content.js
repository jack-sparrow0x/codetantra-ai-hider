let hideSensAI = false;

const LAUNCHER_SELECTOR =
  'button[title^="SensAI - Your AI Assistant for learning"]';

const TOOLS_STRIP_SELECTOR = 'div.ai-tools-strip[role="toolbar"]';

const DIALOG_SELECTOR = 'div.fixed[role="dialog"]';

// 1. Generic selector-based hider
function hideElementBySelector(selector) {
  document.querySelectorAll(selector).forEach((element) => {
    if (hideSensAI) {
      element.style.setProperty("display", "none", "important");
    } else {
      element.style.removeProperty("display");
    }
  });
}

// 2. Generalized text-matcher for popups/cards
function hideElementByTextKeywords(keywords, parentStepsUp = 3) {
  const elements = [...document.querySelectorAll("div, section, aside")].filter(
    (element) =>
      keywords.every((kw) => element.textContent.includes(kw))
  );

  elements.forEach((element) => {
    let target = element;

    // Walk up the DOM tree to grab the actual floating card/container
    for (let i = 0; i < parentStepsUp && target.parentElement; i++) {
      if (
        target.classList.contains("fixed") ||
        target.classList.contains("absolute") ||
        target.classList.contains("shadow") ||
        target.tagName === "DIV"
      ) {
        target = target.parentElement.closest("div") || target;
      }
    }

    if (hideSensAI) {
      target.style.setProperty("display", "none", "important");
    } else {
      target.style.removeProperty("display");
    }
  });
}

function applyState() {
  // Hide static UI elements via selectors
  hideElementBySelector(LAUNCHER_SELECTOR);
  hideElementBySelector(TOOLS_STRIP_SELECTOR);
  hideElementBySelector(DIALOG_SELECTOR);

  // Hide "Get Started with AI" popup
  hideElementByTextKeywords([
    "Get Started with AI",
    "Start using AI features"
  ]);

  // Hide "Are you stuck?" popup
  hideElementByTextKeywords([
    "Are you stuck?",
    "You've been idle for a while"
  ]);

  // Hide "Free Trial Ended" popup
  hideElementByTextKeywords([
    "Free Trial Ended",
    "Subscribe to CodeTantra SensAI"
  ]);

  // Hide compilation-error AI popup
  hideElementByTextKeywords([
    "Your code has compilation errors",
    "Want help fixing them?"
  ]);

  // Hide failed-testcases AI popup
  hideElementByTextKeywords([
    "of your visible testcases failed",
    "Want help fixing them?"
  ]);
}

// Get current state when this frame loads
chrome.storage.local.get("hideAI", (result) => {
  hideSensAI = result.hideAI === true;
  applyState();
});

// Listen for state changes across frames automatically
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;

  if (changes.hideAI) {
    hideSensAI = changes.hideAI.newValue === true;
    applyState();
  }
});

// CodeTantra dynamically creates/removes UI
const observer = new MutationObserver(() => {
  if (hideSensAI) {
    applyState();
  }
});

observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});
